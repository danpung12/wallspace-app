declare module '@expo/vector-icons' {
  import { ComponentType } from 'react';
  import { IconProps } from '@expo/vector-icons/build/createIconSet';

  interface IoniconsComponent extends ComponentType<IconProps<string>> {
    glyphMap: Record<string, number>;
  }

  export const Ionicons: IoniconsComponent;
}

