import * as WebBrowser from 'expo-web-browser';
import * as SecureStore from 'expo-secure-store';
import * as Linking from 'expo-linking';
import { supabase } from './supabase';

type SocialProvider = 'google' | 'kakao' | 'naver';

interface SocialLoginResult {
  success: boolean;
  provider?: SocialProvider;
  naverCode?: string;
  naverState?: string;
  error?: string;
}

async function handleGoogleKakaoLogin(provider: 'google' | 'kakao'): Promise<SocialLoginResult> {

  const saveSessionToSecureStore = async (session: any) => {
    const expiresAt = String(
      session.expires_at > 1_000_000_000
        ? session.expires_at * 1000
        : Date.now() + 3600 * 1000
    );
    await SecureStore.setItemAsync('accessToken', session.access_token);
    await SecureStore.setItemAsync('refreshToken', session.refresh_token ?? '');
    await SecureStore.setItemAsync('tokenExpiresAt', expiresAt);
  };

  const tryExtractSessionFromUrl = async (url?: string | null): Promise<boolean> => {
    if (!url) return false;
    try {
      console.log('[OAuth] tryExtractSessionFromUrl 시작:', url);

      const hashIndex = url.indexOf('#');
      if (hashIndex !== -1) {
        const hash = url.substring(hashIndex + 1);
        const params = new URLSearchParams(hash);
        const accessToken = params.get('access_token');
        const refreshToken = params.get('refresh_token');
        console.log('[OAuth] hash에서 access_token 존재:', !!accessToken);
        if (accessToken) {
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken ?? '',
          });
          console.log('[OAuth] setSession 결과:', !!data.session, error?.message);
          if (error) throw new Error(error.message);
          if (data.session) {
            await saveSessionToSecureStore(data.session);
            console.log('[OAuth] 토큰 추출 성공 (hash)');
            return true;
          }
        }
      }

      const parsed = new URL(url);
      const accessToken = parsed.searchParams.get('access_token');
      const refreshToken = parsed.searchParams.get('refresh_token');
      const errorDesc = parsed.searchParams.get('error_description');
      const errorCode = parsed.searchParams.get('error');
      console.log('[OAuth] query에서 access_token 존재:', !!accessToken, 'error:', errorDesc || errorCode);
      if (errorDesc || errorCode) throw new Error(errorDesc || errorCode || 'OAuth error');

      if (accessToken) {
        const { data, error } = await supabase.auth.setSession({
          access_token: accessToken,
          refresh_token: refreshToken ?? '',
        });
        console.log('[OAuth] setSession 결과 (query):', !!data.session, error?.message);
        if (error) throw new Error(error.message);
        if (data.session) {
          await saveSessionToSecureStore(data.session);
          console.log('[OAuth] 토큰 추출 성공 (query)');
          return true;
        }
      }

      return false;
    } catch (e) {
      console.error('[OAuth] tryExtractSessionFromUrl 에러:', e instanceof Error ? e.message : JSON.stringify(e));
      if (e instanceof Error) throw e;
      throw new Error('URL 처리 중 오류');
    }
  };

  try {
    const appRedirectTo = Linking.createURL('login/social-only');
    console.log('[OAuth] redirectTo:', appRedirectTo);

    const oauthScopes =
      provider === 'google'
        ? 'email profile'
        : provider === 'kakao'
          ? 'account_email profile_nickname profile_image'
          : 'name email profile_image';

    const { data, error } = await supabase.auth.signInWithOAuth({
      provider,
      options: {
        redirectTo: appRedirectTo,
        skipBrowserRedirect: true,
        scopes: oauthScopes,
      },
    });

    console.log('[OAuth] signInWithOAuth 결과 - error:', error?.message, 'url 있음:', !!data?.url);

    if (error) return { success: false, error: error.message };
    if (!data.url) return { success: false, error: 'OAuth URL 생성 실패' };

    console.log('[OAuth] Opening auth session:', data.url);

    let callbackUrlFromEvent: string | null = null;
    const sub = Linking.addEventListener('url', (event) => {
      if (!event?.url) return;
      console.log('[OAuth] URL 이벤트 수신:', event.url);
      callbackUrlFromEvent = event.url;
    });

    try {
      const result = await WebBrowser.openAuthSessionAsync(data.url) as any;
      console.log('[OAuth] Browser result:', JSON.stringify(result));

      if (result.type === 'cancel') {
        return { success: false, error: '로그인이 취소되었습니다.' };
      }

      const candidates = [result?.url, callbackUrlFromEvent].filter(Boolean) as string[];
      console.log('[OAuth] 처리할 URL candidates 수:', candidates.length);

      for (const url of candidates) {
        const ok = await tryExtractSessionFromUrl(url);
        if (ok) return { success: true, provider };
      }

      if (result.type === 'dismiss') {
        console.log('[OAuth] dismiss 후 1초 대기...');
        await new Promise((resolve) => setTimeout(resolve, 1000));
        if (callbackUrlFromEvent) {
          const ok = await tryExtractSessionFromUrl(callbackUrlFromEvent);
          if (ok) return { success: true, provider };
        }
      }

      console.log('[OAuth] 세션 직접 확인...');
      const { data: { session } } = await supabase.auth.getSession();
      console.log('[OAuth] getSession 결과:', !!session);
      if (session) {
        await saveSessionToSecureStore(session);
        return { success: true, provider };
      }

      return { success: false, error: '인증 토큰을 받지 못했습니다.' };

    } finally {
      sub.remove();
    }

  } catch (e: any) {
    console.error('[OAuth] 예상치 못한 오류:', {
      message: e?.message,
      name: e?.name,
      stack: e?.stack,
      raw: JSON.stringify(e),
    });
    return { success: false, error: e?.message || '로그인 중 오류가 발생했습니다.' };
  }
}

async function handleNaverLogin(): Promise<SocialLoginResult> {
  try {
    // 네이버는 앱(WebView)에서 직접 authorize를 여는 대신,
    // 우리 웹 콜백 페이지를 시스템 브라우저에서 열어 처리한다.
    const callbackUrl = `${Linking.createURL('login/social-only')}`;
    const bridgeUrl = `${'https://withart.vercel.app'}/auth/callback/naver?fromApp=1&appCallback=${encodeURIComponent(callbackUrl)}`;

    const result = await WebBrowser.openAuthSessionAsync(bridgeUrl, callbackUrl) as any;
    console.log('[Naver OAuth] Browser result:', JSON.stringify(result));

    if (result.type === 'cancel') {
      return { success: false, error: '로그인이 취소되었습니다.' };
    }

    // social-only 딥링크로 돌아왔을 때 URL에서 토큰/hash 파싱
    const resultUrl: string | undefined = result?.url;
    if (result.type === 'success' && resultUrl) {
      const hashIndex = resultUrl.indexOf('#');
      if (hashIndex !== -1) {
        const hash = resultUrl.substring(hashIndex + 1);
        const params = new URLSearchParams(hash);
        const accessToken = params.get('access_token');
        const refreshToken = params.get('refresh_token');

        if (accessToken) {
          const { data, error } = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken ?? '',
          });
          if (error) return { success: false, error: error.message };

          if (data.session) {
            const expiresAt = String(
              data.session.expires_at > 1_000_000_000
                ? data.session.expires_at * 1000
                : Date.now() + 3600 * 1000
            );
            await SecureStore.setItemAsync('accessToken', data.session.access_token);
            await SecureStore.setItemAsync('refreshToken', data.session.refresh_token ?? '');
            await SecureStore.setItemAsync('tokenExpiresAt', expiresAt);
            return { success: true, provider: 'naver' };
          }
        }
      }

      // 혹시 세션이 이미 반영됐으면 성공 처리
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        const expiresAt = String(
          session.expires_at > 1_000_000_000
            ? session.expires_at * 1000
            : Date.now() + 3600 * 1000
        );
        await SecureStore.setItemAsync('accessToken', session.access_token);
        await SecureStore.setItemAsync('refreshToken', session.refresh_token ?? '');
        await SecureStore.setItemAsync('tokenExpiresAt', expiresAt);
        return { success: true, provider: 'naver' };
      }
    }

    return { success: false, error: '인증 토큰을 받지 못했습니다.' };
  } catch (e: any) {
    return { success: false, error: e?.message || '네이버 로그인 중 오류가 발생했습니다.' };
  }
}

export async function handleSocialLogin(provider: SocialProvider): Promise<SocialLoginResult> {
  if (provider === 'naver') return handleNaverLogin();
  return handleGoogleKakaoLogin(provider);
}

export async function getCurrentSession() {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) return null;
  return session;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}