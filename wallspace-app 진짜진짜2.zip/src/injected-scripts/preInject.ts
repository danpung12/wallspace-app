/**
 * Injected into WebView BEFORE page loads
 * - Detects React Native WebView
 * - Removes mobile bottom nav padding
 * - Handles route changes
 */

// prettier-ignore
export const RN_WEBVIEW_PRE_INJECT = `
(function(){
  try{
    document.documentElement.classList.add('rn-webview');
    document.documentElement.style.setProperty('--bottom-nav-h','0px');
    document.documentElement.style.setProperty('--mobile-extra-padding','0px');
    // Prevent overscroll/bounce effect in React Native WebView
    document.documentElement.style.setProperty('overscroll-behavior','none');
    document.documentElement.style.setProperty('-webkit-overflow-scrolling','touch');
    document.body.style.setProperty('overscroll-behavior','none');
    document.body.style.setProperty('-webkit-overflow-scrolling','touch');
    try {
      if (window && window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_DETECT', source: 'native-preinject', detected: true, ts: Date.now() }));
      }
      if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
        window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_DETECT', source: 'native-preinject', detected: true, ts: Date.now() }));
      }
    } catch(e) {}
    // Remove any inline padding/margin that might have been applied earlier by web scripts and observe for changes
    function clearBottomStyles(){
      try{
        var sel = '.mobile-padding-bottom, .mobile-footer-offset, .mobile-overflow-hidden, .pb-6, footer[role="contentinfo"], .bottom-navigation, .bottom-nav';
        document.querySelectorAll(sel).forEach(function(el){
          try{
            el.style.paddingBottom = '0px';
            el.style.marginBottom = '0px';
            el.style.minHeight = '0px';
            el.style.height = 'auto';
            if (el.matches('footer[role="contentinfo"], .bottom-navigation, .bottom-nav')) {
              el.style.display = 'none';
            }
          }catch(e){}
        });
      }catch(e){}
    }
    function scanAndFixInlinePadding(){
      try{
        var all = document.querySelectorAll('*');
        var reports = [];
        all.forEach(function(el){
          try{
            var inline = el.style && el.style.paddingBottom;
            if (inline && inline.length){
              var lower = inline.toLowerCase();
              var shouldFix = lower.indexOf('var(--bottom-nav-h') !== -1 || lower.indexOf('var(--booking-footer-h') !== -1;
              var computed = 0;
              try { computed = parseFloat(window.getComputedStyle(el).paddingBottom) || 0; } catch(e){}
              if (shouldFix || computed >= 48){
                el.style.paddingBottom = 'env(safe-area-inset-bottom, 0px)';
                el.style.marginBottom = '0px';
                reports.push({ tag: el.tagName, inline: inline, computedBefore: computed });
              }
            }
          }catch(e){}
        });
        if (reports.length){
          try {
            if (window && typeof window.ReactNativeWebView === 'object' && typeof window.ReactNativeWebView.postMessage === 'function') {
              window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_FIX_REPORT', source: 'native-preinject', reports: reports.slice(0,20), ts: Date.now() }));
            }
            if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
              window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_FIX_REPORT', source: 'native-preinject', reports: reports.slice(0,20), ts: Date.now() }));
            }
          } catch(e){}
        }
      }catch(e){}
    }
    try { clearBottomStyles(); } catch(e){}
    try { scanAndFixInlinePadding(); } catch(e){}
    try {
      var mo = new MutationObserver(function(){ clearBottomStyles(); try{ scanAndFixInlinePadding(); }catch(e){} });
      mo.observe(document.documentElement, { attributes: true, childList: true, subtree: true });
    } catch(e){}
    try { setInterval(function(){ clearBottomStyles(); try{ scanAndFixInlinePadding(); }catch(e){} }, 300); } catch(e){}
    // Report CSS variable values and computed paddings for key selectors
    try {
      function reportVarsNative() {
        try {
          var vars = {
            bottomNavH: getComputedStyle(document.documentElement).getPropertyValue('--bottom-nav-h') || '',
            mobileExtraPadding: getComputedStyle(document.documentElement).getPropertyValue('--mobile-extra-padding') || '',
            safeAreaBottom: getComputedStyle(document.documentElement).getPropertyValue('--safe-area-bottom') || '',
          };
          var selectors = ['.mobile-padding-bottom', '.mobile-footer-offset', '.mobile-overflow-hidden', 'footer[role="contentinfo"]', '.bottom-navigation', '.bottom-nav', '.min-h-\\[100dvh\\]'];
          var details = [];
          selectors.forEach(function(sel){
            try{
              var el = document.querySelector(sel);
              if (el) {
                var cs = window.getComputedStyle(el);
                details.push({ selector: sel, paddingBottom: cs.paddingBottom, marginBottom: cs.marginBottom, inline: (el.style && el.style.paddingBottom) || '' });
              } else {
                details.push({ selector: sel, found: false });
              }
            }catch(e){}
          });
          if (window && typeof window.ReactNativeWebView === 'object' && typeof window.ReactNativeWebView.postMessage === 'function') {
            window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_VAR_REPORT', source: 'native-preinject', vars: vars, details: details, ts: Date.now() }));
          }
          if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
            window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_VAR_REPORT', source: 'native-preinject', vars: vars, details: details, ts: Date.now() }));
          }
        } catch(e){}
      }
      try { reportVarsNative(); } catch(e){}
      try { setTimeout(reportVarsNative, 300); } catch(e){}
    } catch(e){}
  // Post-load fixer: run once after full load to clean up any remaining inline paddings/overlays for booking page
  try {
    var RN_POST_LOAD_FIX = "(function(){try{var sel = '.rn-hide-overlay .mobile-padding-bottom, .rn-hide-overlay .mobile-footer-offset, .rn-hide-overlay .mobile-overflow-hidden, .rn-hide-overlay .pb-6'; document.querySelectorAll(sel).forEach(function(el){try{el.style.paddingBottom='env(safe-area-inset-bottom,0px)'; el.style.marginBottom='0px';}catch(e){} }); document.querySelectorAll('.rn-hide-overlay div.fixed.inset-0').forEach(function(el){try{el.style.display='none'; el.style.pointerEvents='none'; el.style.height='0px'; el.style.minHeight='0px';}catch(e){} });}catch(e){}})(); true;";
    try { window.__RN_POST_LOAD_FIX = RN_POST_LOAD_FIX; } catch(e){}
  } catch(e){}
    // Diagnostic: report elements that may be causing bottom spacing
    try {
      function generatePath(el) {
        if (!el) return '';
        var path = [];
        var curr = el;
        while (curr && curr.nodeType === 1 && curr !== document.documentElement) {
          var tag = curr.tagName.toLowerCase();
          var id = curr.id ? '#' + curr.id : '';
          var cls = curr.className && typeof curr.className === 'string' ? '.' + curr.className.trim().split(/\\s+/).join('.') : '';
          path.unshift(tag + id + cls);
          curr = curr.parentElement;
        }
        return path.join(' > ');
      }
      function reportBottomDiagnostics() {
        try {
          var viewportH = window.innerHeight || document.documentElement.clientHeight;
          var candidates = [];
          var all = document.querySelectorAll('*');
          for (var i = 0; i < all.length; i++) {
            var el = all[i];
            try {
              var cs = window.getComputedStyle(el);
              var pb = parseFloat(cs.paddingBottom) || 0;
              var mb = parseFloat(cs.marginBottom) || 0;
              var pos = cs.position;
              var rect = el.getBoundingClientRect();
              var fixedBottom = (pos === 'fixed' || pos === 'sticky') && rect.bottom >= viewportH - 1;
              var overlapsBottom = rect.bottom >= viewportH - 1 && rect.height > 0;
              if (pb > 0 || mb > 0 || fixedBottom || overlapsBottom) {
                candidates.push({
                  tag: el.tagName,
                  path: generatePath(el),
                  paddingBottom: pb,
                  marginBottom: mb,
                  position: pos,
                  rect: { top: Math.round(rect.top), bottom: Math.round(rect.bottom), height: Math.round(rect.height), width: Math.round(rect.width) },
                  inlinePadding: (el.style && el.style.paddingBottom) || ''
                });
              }
            }catch(e){}
          }
          if (candidates.length) {
            try {
              if (window && typeof window.ReactNativeWebView === 'object' && typeof window.ReactNativeWebView.postMessage === 'function') {
                window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_DIAG_REPORT', source: 'native-preinject', items: candidates.slice(0,50), ts: Date.now() }));
              }
              if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
                window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify({ type: 'RN_DIAG_REPORT', source: 'native-preinject', items: candidates.slice(0,50), ts: Date.now() }));
              }
            } catch(e){}
          } else {
            try { console.debug('[withart] RN_DIAG_REPORT: no obvious candidates (native-preinject)'); } catch(e){}
          }
        } catch(e){}
      }
      try { reportBottomDiagnostics(); } catch(e){}
      try { setTimeout(reportBottomDiagnostics, 500); } catch(e){}
    } catch(e){}
  }catch(e){}
  // --- Route -> Native tab sync: post active tab to native when path changes ---
  try {
    var __last_pathname = (location && location.pathname) ? location.pathname : '';
    function __postActiveTabIfChanged() {
      try {
        var p = (location && location.pathname) ? location.pathname : '/';
        if (p !== __last_pathname) {
          __last_pathname = p;
          var tabMap = {'/':'Home','/map':'Map','/dashboard':'Dashboard','/profile':'Profile'};
          var tab = null;
          for (var k in tabMap) {
            if (Object.prototype.hasOwnProperty.call(tabMap, k)) {
              if (p === k || p.indexOf(k + '/') === 0) { tab = tabMap[k]; break; }
            }
          }
          try {
            if (tab && window && window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
              window.ReactNativeWebView.postMessage(JSON.stringify({ type: 'SET_ACTIVE_TAB', tab: tab }));
            }
            if (tab && window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
              window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify({ type: 'SET_ACTIVE_TAB', tab: tab }));
            }
          } catch(e){}
          // Also send tab visibility based on route
          try {
            var hideOnRoutes = ['/login','/onboarding','/find-password','/reset-password','/select-type','/select-type/guest','/select-type/artist','/confirm-booking','/dashboard/add','/dashboard/add-store','/auth/link/naver','/auth/link-account','/auth/callback/naver'];
            var normalized = p && p !== '/' && p.endsWith('/') ? p.slice(0, -1) : p || '/';
            var shouldShowTabs = !hideOnRoutes.includes(normalized);
            var msg = { type: 'SET_TABS_VISIBILITY', visible: shouldShowTabs, pathname: normalized };
            if (window && window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
              window.ReactNativeWebView.postMessage(JSON.stringify(msg));
            }
            if (window && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
              window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify(msg));
            }
          } catch(e){}
        }
      } catch(e){}
    }
    try { __postActiveTabIfChanged(); } catch(e){}
    try { var __origPush = history.pushState; history.pushState = function() { var r = __origPush.apply(this, arguments); try { __postActiveTabIfChanged(); } catch(e){} return r; }; } catch(e){}
    try { var __origReplace = history.replaceState; history.replaceState = function() { var r = __origReplace.apply(this, arguments); try { __postActiveTabIfChanged(); } catch(e){} return r; }; } catch(e){}
    try { window.addEventListener('popstate', __postActiveTabIfChanged); } catch(e){}
    try { setInterval(__postActiveTabIfChanged, 300); } catch(e){}
  } catch(e){}
})(); true;
`;
