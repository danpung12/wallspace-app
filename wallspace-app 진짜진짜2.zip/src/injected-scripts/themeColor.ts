/**
 * Injected into WebView AFTER page loads
 * - Detects page background color for status bar synchronization
 * - Handles tab visibility based on route
 */

// prettier-ignore
export const THEME_COLOR_SCRIPT = `
(function() {
  var lastColor = null;
  var rafPending = false;
  var rafRuns = 0;

  // --- Tab visibility based on route ---
  function getCurrentPathname() {
    try {
      return window.location.pathname || '/';
    } catch(e) { return '/'; }
  }

  function sendTabVisibility(pathname) {
    try {
      var normalized = pathname && pathname !== '/' && pathname.endsWith('/') ? pathname.slice(0, -1) : pathname || '/';
      var hideOnRoutes = ['/login','/onboarding','/find-password','/reset-password','/select-type','/select-type/guest','/select-type/artist','/confirm-booking','/dashboard/add','/dashboard/add-store','/auth/link/naver','/auth/link-account','/auth/callback/naver'];
      var shouldShowTabs = !hideOnRoutes.includes(normalized);
      var msg = { type: 'SET_TABS_VISIBILITY', visible: shouldShowTabs, pathname: normalized };
      if (window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify(msg));
      }
      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.ReactNativeWebView && typeof window.webkit.messageHandlers.ReactNativeWebView.postMessage === 'function') {
        window.webkit.messageHandlers.ReactNativeWebView.postMessage(JSON.stringify(msg));
      }
    } catch(e) {}
  }

  // Send initial tab visibility on page load
  (function(){
    var path = getCurrentPathname();
    sendTabVisibility(path);
  })();

  // Also check periodically in case of browser redirect (not captured by history hooks)
  setInterval(function() {
    try {
      var path = getCurrentPathname();
      sendTabVisibility(path);
    } catch(e) {}
  }, 500);

  // Hook history to send visibility on route change (for SPA navigation)
  function hookHistory(method) {
    var original = window.history[method];
    if (typeof original !== 'function') return;
    try {
      window.history[method] = function() {
        var result = original.apply(this, arguments);
        try {
          var path = window.location.pathname || '/';
          sendTabVisibility(path);
        } catch(e) {}
        return result;
      };
    } catch(e) {}
  }
  hookHistory('pushState');
  hookHistory('replaceState');
  window.addEventListener('popstate', function(){
    try { sendTabVisibility(window.location.pathname || '/'); } catch(e) {}
  });
  // --- End tab visibility ---

  function isTransparent(color) {
    if (!color) return true;
    var normalized = color.replace(/\\s+/g, '').toLowerCase();
    return normalized === 'transparent' || normalized === 'rgba(0,0,0,0)';
  }

  function getOpaqueColor(element) {
    var current = element;
    while (current) {
      try {
        var style = window.getComputedStyle(current);
        if (style && !isTransparent(style.backgroundColor)) {
          return style.backgroundColor;
        }
      } catch (e) {}
      current = current.parentElement;
    }
    try {
      var bodyColor = window.getComputedStyle(document.body).backgroundColor;
      if (bodyColor) {
        return bodyColor;
      }
    } catch (e) {}
    return '#ffffff';
  }

  function detectColor() {
    var probeX = Math.max(1, Math.floor(window.innerWidth / 2));
    var probeY = 1;
    var target = document.elementFromPoint(probeX, probeY);
    var color = getOpaqueColor(target || document.body);

    if (color && color !== lastColor) {
      lastColor = color;
      postColor(color);
    }
  }

  function runBurst() {
    rafRuns = 0;
    rafPending = true;
    var loop = function() {
      detectColor();
      rafRuns += 1;
      if (rafRuns < 8) {
        requestAnimationFrame(loop);
      } else {
        rafPending = false;
      }
    };
    requestAnimationFrame(loop);
  }

  function scheduleDetect(force) {
    if (force) {
      lastColor = null;
    }
    detectColor();
    if (!rafPending) {
      runBurst();
    }
  }

  function routeChanged() {
    scheduleDetect(true);
  }

  function postColor(color) {
    try {
      if (window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'SET_THEME_COLOR',
          color: color
        }));
      }
    } catch (e) {}
  }

  var observer = new MutationObserver(function() {
    scheduleDetect(false);
  });

  function hookHistory(method) {
    var historyRef = window.history;
    if (!historyRef) return;
    var original = historyRef[method];
    if (typeof original !== 'function') return;
    try {
      historyRef[method] = function() {
        var result = original.apply(this, arguments);
        routeChanged();
        return result;
      };
    } catch (e) {}
  }

  window.__WALLSPACE_FORCE_COLOR = function() {
    scheduleDetect(true);
  };

  try {
    observer.observe(document.documentElement, { attributes: true, childList: true, subtree: true });
  } catch (e) {}

  window.addEventListener('load', function() { scheduleDetect(true); });
  window.addEventListener('DOMContentLoaded', function() { scheduleDetect(true); });
  window.addEventListener('readystatechange', function() { scheduleDetect(false); });
  window.addEventListener('pageshow', function() { scheduleDetect(true); });
  window.addEventListener('visibilitychange', function() { scheduleDetect(false); });
  window.addEventListener('scroll', function() { scheduleDetect(false); }, true);
  window.addEventListener('resize', function() { scheduleDetect(false); });
  window.addEventListener('hashchange', routeChanged);
  window.addEventListener('popstate', routeChanged);

  hookHistory('pushState');
  hookHistory('replaceState');

  setInterval(function() { scheduleDetect(false); }, 800);
  scheduleDetect(true);
})(); true;
`;

export const REQUEST_THEME_COLOR_SCRIPT =
  "window.__WALLSPACE_FORCE_COLOR && window.__WALLSPACE_FORCE_COLOR(); true;";
