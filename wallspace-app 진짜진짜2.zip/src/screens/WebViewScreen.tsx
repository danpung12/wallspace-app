import React, { useRef, useCallback, useContext, useEffect } from 'react';
import { StyleSheet, View, Alert, Platform, StatusBar as RNStatusBar } from 'react-native';
import WebView, { WebViewMessageEvent, WebViewNavigation } from 'react-native-webview';
import { useFocusEffect } from '@react-navigation/native';
import * as SecureStore from 'expo-secure-store';
import { AuthContext } from '../contexts/AuthContext';
import { useAuthFlowStore } from '../store/authFlowStore';
import { RN_WEBVIEW_PRE_INJECT } from '../injected-scripts/preInject';
import { THEME_COLOR_SCRIPT } from '../injected-scripts/themeColor';
import { webviewControllerRegistry } from '../lib/webviewController';
import { useWebviewReady } from '../contexts/WebviewReadyContext';

const CUSTOM_USER_AGENT =
  Platform.OS === 'ios'
    ? 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1 WithartApp/1.0'
    : 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 WithartApp/1.0';

const WEBVIEW_DEBUG_BRIDGE_SCRIPT = `(function() {
  if (window.__RN_WEBVIEW_DEBUG_BRIDGE__) return;
  window.__RN_WEBVIEW_DEBUG_BRIDGE__ = true;

  var post = function(type, payload) {
    try {
      if (window.ReactNativeWebView && typeof window.ReactNativeWebView.postMessage === 'function') {
        window.ReactNativeWebView.postMessage(JSON.stringify({ type: type, payload: payload || {} }));
      }
    } catch (_) {}
  };

  window.addEventListener('error', function(e) {
    post('WEBVIEW_ERROR', {
      message: e && e.message ? e.message : 'Unknown window error',
      source: e && e.filename ? e.filename : null,
      line: e && typeof e.lineno === 'number' ? e.lineno : null,
      column: e && typeof e.colno === 'number' ? e.colno : null,
      stack: e && e.error && e.error.stack ? e.error.stack : null
    });
  });

  window.addEventListener('unhandledrejection', function(e) {
    var reason = e ? e.reason : null;
    post('WEBVIEW_UNHANDLED_REJECTION', {
      message: reason && reason.message ? reason.message : String(reason),
      stack: reason && reason.stack ? reason.stack : null
    });
  });

  var originalLog = console.log;
  var originalWarn = console.warn;
  var originalError = console.error;

  console.log = function() {
    try { post('WEBVIEW_CONSOLE', { level: 'log', args: Array.prototype.slice.call(arguments) }); } catch (_) {}
    return originalLog && originalLog.apply(console, arguments);
  };

  console.warn = function() {
    try { post('WEBVIEW_CONSOLE', { level: 'warn', args: Array.prototype.slice.call(arguments) }); } catch (_) {}
    return originalWarn && originalWarn.apply(console, arguments);
  };

  console.error = function() {
    try { post('WEBVIEW_CONSOLE', { level: 'error', args: Array.prototype.slice.call(arguments) }); } catch (_) {}
    return originalError && originalError.apply(console, arguments);
  };
})();true;`;

type Props = {
  url: string;
  name?: string;
  onCustomMessage?: (type: string, data?: any) => void;
  onPathChange?: (pathname: string) => void;
  onReady?: () => void;
};

const LOGIN_PATH_PREFIXES = ['/login', '/auth'];

function isLoginLikePath(pathname: string): boolean {
  const normalized = pathname !== '/' && pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;
  return LOGIN_PATH_PREFIXES.some((prefix) => normalized === prefix || normalized.startsWith(`${prefix}/`));
}

function getStatusBarColorByUrl(url: string): string {
  try {
    const pathname = new URL(url).pathname || '/';
    if (pathname.startsWith('/dashboard')) return '#F5F1EC';
    if (pathname.startsWith('/profile')) return '#FAF8F5';
    if (pathname.startsWith('/map')) return '#F5F1EC';
    if (pathname === '/' || pathname.startsWith('/home')) return '#E8E3DA';
    return '#F5F1EC';
  } catch (_) {
    return '#F5F1EC';
  }
}

function applyAndroidStatusBarByUrl(url: string) {
  if (Platform.OS !== 'android') return;
  const color = getStatusBarColorByUrl(url);
  try {
    RNStatusBar.setBarStyle('dark-content', true);
    RNStatusBar.setTranslucent(false);
    RNStatusBar.setBackgroundColor(color, true);
  } catch (_) {}
}

export default function WebViewScreen({ url, name, onCustomMessage, onPathChange, onReady }: Props) {
  const webViewRef = useRef<WebView>(null);
  const currentPathRef = useRef<string | null>(null);
  const { onLogout } = useContext(AuthContext);
  const { setIsWebviewReady } = useWebviewReady();
  const authHydrationPending = useAuthFlowStore((s) => s.authHydrationPending);
  const prevAuthHydrationRef = useRef<boolean>(true);
  const readySentRef = useRef(false);
  const lastInjectedAuthKeyRef = useRef<string | null>(null);
  const lastInjectedAuthAtRef = useRef(0);

  // ✅ 1. redirectFromLoginIfNeeded 먼저 선언
  const redirectFromLoginIfNeeded = useCallback(() => {
    const js = `(function(){
      try {
        var p = window.location.pathname || '/';
        var isLogin = p === '/login' || p === '/login/social-only' || p.indexOf('/login/') === 0 || p === '/auth' || p.indexOf('/auth/') === 0;
        if (isLogin) {
          window.location.replace('/');
        }
      } catch (e) {}
    })();true;`;
    webViewRef.current?.injectJavaScript(js);
  }, []);

  const navigateToPath = useCallback((path: string) => {
    try {
      const safePath = path && path.startsWith('/') ? path : '/';
      console.log('[WebViewScreen][nav] navigateToPath called', {
        name,
        currentPath: currentPathRef.current,
        targetPath: safePath,
      });
      // Optimistically update ref so native callers get correct path immediately
      currentPathRef.current = safePath;
      const js = `(function(){
        try {
          var target = ${JSON.stringify(safePath)};
          var current = (window.location.pathname || '/') + (window.location.search || '');
          if (current === target) return;

          // 1) 즉시 SPA 전환 시도
          try {
            window.history.pushState({}, '', target);
            window.dispatchEvent(new PopStateEvent('popstate'));
            window.dispatchEvent(new Event('pushstate'));
          } catch (e) {}

          // 2) 다음 프레임에서 미전환 시 anchor fallback
          setTimeout(function(){
            try {
              var now1 = (window.location.pathname || '/') + (window.location.search || '');
              if (now1 === target) return;
              var a = document.createElement('a');
              a.href = target;
              a.style.display = 'none';
              document.body.appendChild(a);
              a.click();
              setTimeout(function(){
                try { document.body.removeChild(a); } catch(e) {}
              }, 0);
            } catch (e) {}
          }, 16);
        } catch (e) {}
      })();true;`;
      webViewRef.current?.injectJavaScript(js);
    } catch (_) {}
  }, [name]);

  const reload = useCallback(() => {
    try {
      webViewRef.current?.reload();
    } catch (_) {}
  }, []);

  // ✅ 2. injectSession 선언
  const injectSession = useCallback((payload?: { accessToken?: string; refreshToken?: string; tokenExpiresAt?: string }) => {
    try {
      const accessToken = payload?.accessToken;
      const refreshToken = payload?.refreshToken;
      const expiresAt = payload?.tokenExpiresAt;
      console.log('[WebViewScreen][auth] injectSession called', {
        name,
        currentPath: currentPathRef.current,
        hasAccessToken: !!accessToken,
        hasRefreshToken: !!refreshToken,
        hasExpiresAt: !!expiresAt,
      });
      if (!accessToken || !refreshToken || !expiresAt) return;

      const expiresAtRaw = parseInt(expiresAt, 10);
      if (!Number.isFinite(expiresAtRaw)) return;
      if (expiresAtRaw <= Date.now()) return;

      const dedupeKey = `${accessToken.slice(0, 10)}:${refreshToken.slice(0, 10)}:${expiresAt}`;
      const now = Date.now();
      if (lastInjectedAuthKeyRef.current === dedupeKey && now - lastInjectedAuthAtRef.current < 4000) {
        return;
      }
      lastInjectedAuthKeyRef.current = dedupeKey;
      lastInjectedAuthAtRef.current = now;

      const expiresAtMs = expiresAtRaw < 1_000_000_000_000 ? expiresAtRaw * 1000 : expiresAtRaw;
      const session = {
        access_token: accessToken,
        refresh_token: refreshToken,
        expires_at: Math.floor(expiresAtMs / 1000),
        token_type: 'bearer',
      };

      const sessionJson = JSON.stringify(session);
      const js = `(function(){
        try {
          const accessToken = ${JSON.stringify(accessToken)};
          const refreshToken = ${JSON.stringify(refreshToken)};
          const expiresAt = ${JSON.stringify(expiresAt)};
          const sessionJson = ${JSON.stringify(sessionJson)};
          const supabaseStorageKey = ${JSON.stringify('sb-gnhwzbvlaqdnkahurlbv-auth-token')};

          localStorage.setItem(supabaseStorageKey, sessionJson);
          localStorage.setItem('sb-access-token', accessToken);
          localStorage.setItem('sb-refresh-token', refreshToken);
          localStorage.setItem('sb-expires-at', expiresAt);
          localStorage.setItem('sb-session', sessionJson);
          localStorage.setItem('supabase.auth.token', sessionJson);

          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!key) continue;
            if (key.startsWith('sb-') && key.endsWith('-auth-token')) {
              localStorage.setItem(key, sessionJson);
            }
          }

          window.dispatchEvent(new Event('storage'));
          window.dispatchEvent(new Event('authstatechange'));
        } catch (e) {
          console.error('Auth inject error:', e);
        }
      })();true;`;

      webViewRef.current?.injectJavaScript(js);

    } catch (_) {}
  }, [name]);

  // ✅ 3. useEffect (registry 등록)
  useEffect(() => {
    if (!name) return;
    webviewControllerRegistry.set(name, {
      redirectFromLoginIfNeeded,
      injectSession,
      navigateToPath,
      reload,
      getCurrentPath: () => currentPathRef.current,
    });
    return () => {
      webviewControllerRegistry.set(name, null);
    };
  }, [name, redirectFromLoginIfNeeded, injectSession, navigateToPath, reload]);

  // authHydrationPending이 false로 변하면 → 로그인 완료 → 모든 WebView에 세션 주입
  useEffect(() => {
    if (prevAuthHydrationRef.current && !authHydrationPending) {
      injectAuth({ force: true });
    }
    prevAuthHydrationRef.current = authHydrationPending;
  }, [authHydrationPending]);

  useFocusEffect(
    useCallback(() => {
      applyAndroidStatusBarByUrl(url);
      if (authHydrationPending) return;
      if (name !== 'main') return;
      injectAuth({ force: false });
    }, [url, authHydrationPending, name])
  );

  const injectAuth = async (options?: { force?: boolean }) => {
    try {
      if (!options?.force && currentPathRef.current && isLoginLikePath(currentPathRef.current)) {
        return;
      }
      const accessToken = await SecureStore.getItemAsync('accessToken');
      const refreshToken = await SecureStore.getItemAsync('refreshToken');
      const tokenExpiresAt = await SecureStore.getItemAsync('tokenExpiresAt');
      injectSession({
        accessToken: accessToken || undefined,
        refreshToken: refreshToken || undefined,
        tokenExpiresAt: tokenExpiresAt || undefined,
      });
    } catch (_) {}
  };

  const handleNavChange = useCallback((navState: WebViewNavigation) => {
    try {
      const parsed = new URL(navState.url);
      const pathname = parsed.pathname || '/';
      const prevPath = currentPathRef.current;
      currentPathRef.current = pathname;
      console.log('[WebViewScreen][nav] navigation change', {
        name,
        prevPath,
        nextPath: pathname,
        url: navState.url,
      });
      onPathChange?.(pathname);

      // 로그인 플로우에서는 main WebView가 /login|/auth를 벗어났을 때만 READY
      if (name === 'main' && !isLoginLikePath(pathname)) {
        console.log('[WebViewScreen][nav] main ready after auth-like path exit', {
          pathname,
        });
        setIsWebviewReady(true);
      }
    } catch (_) {}
    applyAndroidStatusBarByUrl(navState.url);
  }, [onPathChange, name, setIsWebviewReady]);

  const handleShouldStartLoadWithRequest = useCallback((_request: any) => {
    return true;
  }, []);

  const handleMessage = useCallback(
    (event: WebViewMessageEvent) => {
      try {
        const msg = JSON.parse(event.nativeEvent.data);
        if (!msg?.type) return;

        // WebView 내부 디버그/에러 브리지 로그는 과도하게 쌓여
        // 실제 복구 로그 확인을 방해하므로 기본적으로 출력하지 않는다.
        if (
          msg.type === 'WEBVIEW_ERROR' ||
          msg.type === 'WEBVIEW_UNHANDLED_REJECTION' ||
          msg.type === 'WEBVIEW_CONSOLE'
        ) {
          return;
        }

        if (msg.type === 'LOGOUT') {
          onLogout();
          return;
        }

        if (onCustomMessage) {
          onCustomMessage(msg.type, msg);
        }
      } catch (_) {}
    },
    [onLogout, onCustomMessage]
  );

  const handleLoadEnd = useCallback(async () => {
    console.log('[WebViewScreen][load] onLoadEnd', {
      name,
      currentPath: currentPathRef.current,
    });
    await injectAuth();

    if (!readySentRef.current) {
      readySentRef.current = true;
      onReady?.();
      onCustomMessage?.('WEBVIEW_READY');
    }

    // main은 경로 확인(onNavigationStateChange)에서만 READY 처리
    if (name !== 'main') {
      setIsWebviewReady(true);
    }
  }, [injectAuth, name, setIsWebviewReady, onReady, onCustomMessage]);

  return (
    <View style={styles.container}>
      <WebView
        ref={webViewRef}
        source={{ uri: url }}
        style={styles.webview}
        userAgent={CUSTOM_USER_AGENT}
        onMessage={handleMessage}
        onLoadEnd={handleLoadEnd}
        onNavigationStateChange={handleNavChange}
        onShouldStartLoadWithRequest={handleShouldStartLoadWithRequest}
        injectedJavaScriptBeforeContentLoaded={`${RN_WEBVIEW_PRE_INJECT}\n;${WEBVIEW_DEBUG_BRIDGE_SCRIPT}`}
        injectedJavaScriptBeforeContentLoadedForMainFrameOnly={false}
        injectedJavaScript={`${WEBVIEW_DEBUG_BRIDGE_SCRIPT}\n;${THEME_COLOR_SCRIPT}`}
        onError={(syntheticEvent) => {
          const { nativeEvent } = syntheticEvent;
          console.error('[WebView Error]', nativeEvent.description);
          setIsWebviewReady(true);
        }}
        onHttpError={(syntheticEvent) => {
          const { nativeEvent } = syntheticEvent;
          console.error('[WebView HTTP Error]', nativeEvent.statusCode, nativeEvent.description);
          setIsWebviewReady(true);
        }}
        allowsBackForwardNavigationGestures
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        javaScriptEnabled
        domStorageEnabled
        geolocationEnabled
        originWhitelist={['*']}
        mixedContentMode="always"
        onRenderProcessGone={(event) => {
          console.error('[WebView Process Gone]', event.nativeEvent.didCrash);
          Alert.alert('앱 에러', 'WebView가 충돌했습니다. 다시 시도해주세요.');
        }}
        pullToRefreshEnabled={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F1EC',
  },
  webview: {
    flex: 1,
  },
});