import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Image,
} from "react-native";
import Svg, { Path } from "react-native-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const THEME_MAIN = "#A3834C";
const TEXT_MUTED = "#8A7B6B";
const BG = "#F9F6F2";

type SocialProvider = "kakao" | "naver" | "google";

type NativeLoginScreenProps = {
  onSocialLogin: (provider: SocialProvider) => void;
  onNormalLogin: () => void;
  onSignUp: () => void;
};

export default function NativeLoginScreen({
  onSocialLogin,
  onNormalLogin,
  onSignUp,
}: NativeLoginScreenProps) {
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.container,
        { paddingTop: insets.top, paddingBottom: insets.bottom },
      ]}
    >
      <View style={styles.backgroundPattern}>
        <View style={styles.topDecoration} />
        <View style={styles.bottomDecoration} />
      </View>

      {/* 로고 + 브랜딩 텍스트 */}
      <View style={styles.logoSection}>
        <View style={styles.logoCircle}>
          <Image
            source={require("../../assets/logo3.png")}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.brandName}>위드아트</Text>
        <Text style={styles.brandDesc}>카페 그림 전시 예약 앱</Text>
      </View>

      <View style={styles.formCard}>
        {/* 간편 로그인 아이콘 (가로 3개) */}
        <View style={styles.socialIconRow}>
          {/* 네이버 */}
          <View style={styles.socialIconWrapper}>
            <View
              style={[
                styles.socialIconBtn,
                styles.socialIconDisabled,
                { backgroundColor: "#03C75A", opacity: 0.4 },
              ]}
            >
              <NaverIcon />
            </View>
          </View>

          {/* 카카오 */}
          <View style={styles.socialIconWrapper}>
            <View
              style={[
                styles.socialIconBtn,
                styles.socialIconDisabled,
                { backgroundColor: "#FEE500", opacity: 0.4 },
              ]}
            >
              <KakaoIcon />
            </View>
          </View>

          {/* 구글 */}
          <View style={styles.socialIconWrapper}>
            <Pressable
              style={({ pressed }) => [
                styles.socialIconBtn,
                {
                  backgroundColor: "#FFFFFF",
                  borderWidth: 1,
                  borderColor: "#E0E0E0",
                },
                pressed && styles.socialIconPressed,
              ]}
              onPress={() => onSocialLogin("google")}
            >
              <GoogleIcon />
            </Pressable>
          </View>
        </View>

        <View style={styles.dividerContainer}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>또는</Text>
          <View style={styles.dividerLine} />
        </View>

        <Pressable
          style={({ pressed }) => [
            styles.footerBtn,
            styles.footerBtnOutline,
            pressed && styles.footerBtnPressed,
          ]}
          onPress={onNormalLogin}
        >
          <Text style={styles.footerBtnTextOutline}>이메일로 로그인</Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.footerBtn,
            styles.footerBtnPrimary,
            pressed && styles.footerBtnPressed,
          ]}
          onPress={onSignUp}
        >
          <Text style={styles.footerBtnTextPrimary}>회원가입</Text>
        </Pressable>
      </View>
    </View>
  );
}

/* ── 소셜 아이콘 컴포넌트 (웹 LoginClient의 SVG를 View/Text로 재현) ── */

function NaverIcon() {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
      <Path
        d="M15.9 12.825L9.15 3H3v18h6.15V11.175L15.9 21H21V3h-5.1v9.825z"
        fill="#fff"
      />
    </Svg>
  );
}

function KakaoIcon() {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
      <Path
        d="M12 2C6.477 2 2 5.82 2 10.5C2 13.533 3.808 16.202 6.48 17.539L6 22l4.33-2.598C10.896 19.46 11.442 19.5 12 19.5c5.523 0 10-3.82 10-9S17.523 2 12 2z"
        fill="#181600"
      />
    </Svg>
  );
}

function GoogleIcon() {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none">
      <Path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <Path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <Path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"
        fill="#FBBC05"
      />
      <Path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </Svg>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
    paddingHorizontal: 24,
  },
  backgroundPattern: {
    ...StyleSheet.absoluteFillObject,
    overflow: "hidden",
  },
  topDecoration: {
    position: "absolute",
    top: -80,
    left: -80,
    width: 250,
    height: 250,
    borderRadius: 125,
    backgroundColor: "rgba(163, 131, 76, 0.1)",
  },
  bottomDecoration: {
    position: "absolute",
    bottom: -100,
    right: -100,
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: "rgba(163, 131, 76, 0.06)",
  },
  logoSection: {
    alignItems: "center",
    marginTop: 96,
    marginBottom: 40,
  },
  logoCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: THEME_MAIN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 6,
  },
  logo: {
    width: 70,
    height: 70,
  },
  brandName: {
    marginTop: 16,
    fontSize: 26,
    fontWeight: "800",
    color: "#3A2F24",
    letterSpacing: 1,
  },
  brandDesc: {
    marginTop: 6,
    fontSize: 14,
    fontWeight: "500",
    color: TEXT_MUTED,
    letterSpacing: 0.5,
  },
  formCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 24,
    padding: 28,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 5,
  },
  /* ── 간편 로그인 아이콘 (가로 배치) ── */
  socialIconRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 24,
    marginBottom: 4,
  },
  socialIconWrapper: {
    alignItems: "center",
  },
  socialIconBtn: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  socialIconPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.95 }],
  },
  socialIconDisabled: {
    transform: [{ scale: 0.9 }],
  },
  dividerContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: "#EEEEEE",
  },
  dividerText: {
    color: TEXT_MUTED,
    fontSize: 12,
    marginHorizontal: 16,
  },
  footerBtn: {
    height: 54,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
  },
  footerBtnOutline: {
    borderWidth: 1.5,
    borderColor: THEME_MAIN,
    backgroundColor: "transparent",
  },
  footerBtnPrimary: {
    backgroundColor: THEME_MAIN,
    shadowColor: THEME_MAIN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  footerBtnPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  footerBtnTextOutline: {
    fontSize: 15,
    fontWeight: "600",
    color: THEME_MAIN,
  },
  footerBtnTextPrimary: {
    fontSize: 15,
    fontWeight: "600",
    color: "#FFFFFF",
  },
});
