import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  TouchableWithoutFeedback,
  StyleSheet,
  Animated,
  LayoutChangeEvent,
  Platform,
} from 'react-native';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

type Props = BottomTabBarProps & {
  isVisible?: boolean;
  activeRouteName?: string;
};

export default function AnimatedTabBar({ state, descriptors, navigation, isVisible = true, activeRouteName }: Props) {
  const [width, setWidth] = useState(0);
  const translateX = useRef(new Animated.Value(0)).current;
  const indicatorScale = useRef(new Animated.Value(1)).current;
  const iconScales = useRef(state.routes.map(() => new Animated.Value(1))).current;

  const visualIndex = React.useMemo(() => {
    if (!activeRouteName) return state.index;
    const idx = state.routes.findIndex((r) => r.name === activeRouteName);
    return idx >= 0 ? idx : state.index;
  }, [activeRouteName, state.index, state.routes]);

  useEffect(() => {
    const index = visualIndex;
    if (width === 0) return;
    const itemWidth = width / state.routes.length;
    Animated.spring(translateX, {
      toValue: index * itemWidth + itemWidth / 2 - (itemWidth * 0.6) / 2,
      useNativeDriver: true,
      speed: 20,
      bounciness: 8,
    }).start();

    // icon scale animations
    iconScales.forEach((anim, i) => {
      Animated.spring(anim, {
        toValue: i === index ? 1.15 : 1,
        useNativeDriver: true,
      }).start();
    });
  }, [visualIndex, width]);

  const onLayout = (e: LayoutChangeEvent) => {
    setWidth(e.nativeEvent.layout.width);
  };

  if (!isVisible) {
    return null;
  }

  const itemWidth = width && state.routes.length ? width / state.routes.length : 64;

  return (
    <View style={styles.container} onLayout={onLayout}>
      <View style={styles.inner}>
        {state.routes.map((route, idx) => {
          const { options } = descriptors[route.key];
          const label =
            options.title !== undefined ? options.title : route.name;
          const focused = visualIndex === idx;

          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });

            if (!focused && !event.defaultPrevented) {
              navigation.navigate(route.name as never);
            }
          };

          const onLongPress = () => {
            navigation.emit({
              type: 'tabLongPress',
              target: route.key,
            });
          };

          const color = focused ? '#A3834C' : '#8B8B8B';

          return (
            <TouchableWithoutFeedback key={route.key} onPress={onPress} onLongPress={onLongPress}>
              <View style={[styles.tabItem, { width: itemWidth }]}>
                <Animated.View style={{ transform: [{ scale: iconScales[idx] }] }}>
                  {/* try to use the provided tabBarIcon if available */}
                  {typeof options.tabBarIcon === 'function' ? (
                    options.tabBarIcon({ color, size: 20, focused })
                  ) : (
                    <Ionicons
                      name={(options as any).tabBarIconName || 'home-outline'}
                      size={20}
                      color={color}
                    />
                  )}
                </Animated.View>
                <Text style={[styles.label, { color }]} numberOfLines={1}>
                  {label}
                </Text>
              </View>
            </TouchableWithoutFeedback>
          );
        })}
      </View>

      {/* indicator */}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.indicator,
          {
            width: itemWidth ? itemWidth * 0.6 : 40,
            transform: [{ translateX }],
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#F5F1EC',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#E2E2E2',
    paddingBottom: Platform.OS === 'ios' ? 12 : 8,
    paddingTop: 6,
    zIndex: 30,
  },
  inner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  tabItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
  },
  label: {
    fontSize: 11,
    marginTop: 2,
    fontWeight: '600',
  },
  indicator: {
    height: 3,
    backgroundColor: '#A3834C',
    borderRadius: 2,
    position: 'absolute',
    bottom: Platform.OS === 'ios' ? 6 : 4,
    left: 0,
  },
});



